#!/bin/bash
ping -c 5 8.8.8.8
